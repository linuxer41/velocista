figure;
bode(Gz);
title('Diagrama de Bode - Sistema discreto');
grid on;